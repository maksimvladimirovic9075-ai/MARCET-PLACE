namespace wb
{
    partial class UserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.panelSidebar = new System.Windows.Forms.Panel();
            this.panelTop = new System.Windows.Forms.Panel();
            this.panelContent = new System.Windows.Forms.Panel();
            this.panelHome = new System.Windows.Forms.Panel();
            this.panelCategories = new System.Windows.Forms.Panel();
            this.panelFavorites = new System.Windows.Forms.Panel();
            this.panelCart = new System.Windows.Forms.Panel();
            this.panelProfile = new System.Windows.Forms.Panel();
            this.flowProducts = new System.Windows.Forms.FlowLayoutPanel();
            this.flowFavorites = new System.Windows.Forms.FlowLayoutPanel();
            this.listCart = new System.Windows.Forms.DataGridView();
            this.listOrders = new System.Windows.Forms.DataGridView();
            this.cmbCategories = new System.Windows.Forms.ComboBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = MakeButton("btnSearch", "Найти", 730, 20, 110, 38);
            this.btnHome = MakeMenu("btnHome", "Главная", 100);
            this.btnCategories = MakeMenu("btnCategories", "Категории", 156);
            this.btnFavorites = MakeMenu("btnFavorites", "Избранное", 212);
            this.btnCart = MakeMenu("btnCart", "Корзина", 268);
            this.btnProfile = MakeMenu("btnProfile", "Профиль", 324);
            this.lblLogo = new System.Windows.Forms.Label();
            this.lblCartTotal = MakeLabel("lblCartTotal", "Итого: 0 ₽", 25, 590, 20, true);
            this.lblProfileName = MakeLabel("lblProfileName", "Имя", 30, 110, 14, true);
            this.lblProfileEmail = MakeLabel("lblProfileEmail", "Почта", 30, 155, 12, false);
            this.lblProfileRole = MakeLabel("lblProfileRole", "Покупатель", 30, 200, 12, false);
            this.btnCheckout = MakeButton("btnCheckout", "Оформить заказ", 720, 590, 220, 46);
            this.btnRemoveCart = MakeButton("btnRemoveCart", "Удалить выбранное", 25, 645, 190, 40);
            this.btnMinus = MakeButton("btnMinus", "−", 230, 645, 55, 40);
            this.btnPlus = MakeButton("btnPlus", "+", 300, 645, 55, 40);
            this.btnLogout = MakeButton("btnLogout", "Выйти из аккаунта", 30, 255, 220, 44);
            this.btnShowCategory = MakeButton("btnShowCategory", "Показать товары", 330, 135, 210, 44);
            this.lblLogo.Text = "WB"; this.lblLogo.Font = new System.Drawing.Font("Segoe UI Black", 35F, System.Drawing.FontStyle.Bold);
            this.lblLogo.ForeColor = Purple; this.lblLogo.AutoSize = true; this.lblLogo.Location = new System.Drawing.Point(24, 12);
            this.panelSidebar.Dock = System.Windows.Forms.DockStyle.Left; this.panelSidebar.Width = 238; this.panelSidebar.BackColor = System.Drawing.Color.White;
            this.panelSidebar.Controls.AddRange(new System.Windows.Forms.Control[] { lblLogo, btnHome, btnCategories, btnFavorites, btnCart, btnProfile });
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top; this.panelTop.Height = 92; this.panelTop.BackColor = System.Drawing.Color.White;
            this.txtSearch.Name = "txtSearch"; this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 12F); this.txtSearch.Location = new System.Drawing.Point(25, 24); this.txtSearch.Size = new System.Drawing.Size(690, 35); this.txtSearch.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            this.btnSearch.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.panelTop.Controls.AddRange(new System.Windows.Forms.Control[] { txtSearch, btnSearch });
            this.panelContent.Dock = System.Windows.Forms.DockStyle.Fill; this.panelContent.BackColor = Bg;
            System.Windows.Forms.Panel[] pages = { panelHome, panelCategories, panelFavorites, panelCart, panelProfile };
            string[] names = { "panelHome", "panelCategories", "panelFavorites", "panelCart", "panelProfile" };
            for (int i = 0; i < pages.Length; i++) { pages[i].Name = names[i]; pages[i].Dock = System.Windows.Forms.DockStyle.Fill; pages[i].BackColor = Bg; this.panelContent.Controls.Add(pages[i]); }
            this.flowProducts.Name = "flowProducts"; this.flowProducts.Dock = System.Windows.Forms.DockStyle.Fill; this.flowProducts.AutoScroll = true; this.flowProducts.Padding = new System.Windows.Forms.Padding(12);
            this.panelHome.Controls.Add(flowProducts);
            this.panelCategories.Controls.Add(MakeLabel("lblCategoriesTitle", "Категории", 25, 28, 22, true));
            this.panelCategories.Controls.Add(MakeLabel("lblCategoriesHint", "Выберите категорию и откройте товары", 27, 83, 11, false));
            this.cmbCategories.Name = "cmbCategories"; this.cmbCategories.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList; this.cmbCategories.Location = new System.Drawing.Point(27, 142); this.cmbCategories.Size = new System.Drawing.Size(280, 32); this.cmbCategories.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.panelCategories.Controls.AddRange(new System.Windows.Forms.Control[] { cmbCategories, btnShowCategory });
            this.panelFavorites.Controls.Add(MakeLabel("lblFavoritesTitle", "Избранное", 25, 20, 22, true));
            this.flowFavorites.Name = "flowFavorites"; this.flowFavorites.Location = new System.Drawing.Point(15, 85); this.flowFavorites.Size = new System.Drawing.Size(980, 650); this.flowFavorites.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right; this.flowFavorites.AutoScroll = true; this.flowFavorites.Padding = new System.Windows.Forms.Padding(10);
            this.panelFavorites.Controls.Add(flowFavorites);
            this.panelCart.Controls.Add(MakeLabel("lblCartTitle", "Моя корзина", 25, 20, 22, true));
            this.listCart.Name = "listCart"; this.listCart.Location = new System.Drawing.Point(25, 85); this.listCart.Size = new System.Drawing.Size(920, 480); this.listCart.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right; this.listCart.ReadOnly = true; this.listCart.AllowUserToAddRows = false; this.listCart.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect; this.listCart.MultiSelect = false; this.listCart.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill; this.listCart.BackgroundColor = System.Drawing.Color.White;
            this.panelCart.Controls.AddRange(new System.Windows.Forms.Control[] { listCart, lblCartTotal, btnCheckout, btnRemoveCart, btnMinus, btnPlus });
            this.panelProfile.Controls.Add(MakeLabel("lblProfileTitle", "Мой профиль", 25, 20, 22, true));
            this.panelProfile.Controls.AddRange(new System.Windows.Forms.Control[] { lblProfileName, lblProfileEmail, lblProfileRole, btnLogout });
            this.panelProfile.Controls.Add(MakeLabel("lblOrdersTitle", "История заказов", 30, 340, 18, true));
            this.listOrders.Name = "listOrders"; this.listOrders.Location = new System.Drawing.Point(30, 400); this.listOrders.Size = new System.Drawing.Size(900, 280); this.listOrders.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right; this.listOrders.ReadOnly = true; this.listOrders.AllowUserToAddRows = false; this.listOrders.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill; this.listOrders.BackgroundColor = System.Drawing.Color.White;
            this.panelProfile.Controls.Add(listOrders);
            this.Controls.Add(panelContent); this.Controls.Add(panelTop); this.Controls.Add(panelSidebar);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; this.ClientSize = new System.Drawing.Size(1265, 864); this.MinimumSize = new System.Drawing.Size(1100, 760); this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen; this.Text = "WB — Маркетплейс"; this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            this.btnCategories.Click += new System.EventHandler(this.btnCategories_Click);
            this.btnFavorites.Click += new System.EventHandler(this.btnFavorites_Click);
            this.btnCart.Click += new System.EventHandler(this.btnCart_Click);
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            this.btnShowCategory.Click += new System.EventHandler(this.btnShowCategory_Click);
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click);
            this.btnRemoveCart.Click += new System.EventHandler(this.btnRemoveCart_Click);
            this.btnPlus.Click += new System.EventHandler(this.btnPlus_Click);
            this.btnMinus.Click += new System.EventHandler(this.btnMinus_Click);
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            this.Load += new System.EventHandler(this.UserForm_Load);
            this.ResumeLayout(false);
        }
        private static readonly System.Drawing.Color Purple = System.Drawing.Color.FromArgb(111, 45, 220);
        private static readonly System.Drawing.Color Bg = System.Drawing.Color.FromArgb(248, 249, 253);
        private System.Windows.Forms.Button MakeMenu(string name, string title, int y) { var b = MakeButton(name, title, 12, y, 204, 48); b.BackColor = System.Drawing.Color.White; b.ForeColor = Purple; b.TextAlign = System.Drawing.ContentAlignment.MiddleLeft; return b; }
        private System.Windows.Forms.Button MakeButton(string name, string title, int x, int y, int w, int h) { var b = new System.Windows.Forms.Button(); b.Name = name; b.Text = title; b.Location = new System.Drawing.Point(x, y); b.Size = new System.Drawing.Size(w, h); b.BackColor = Purple; b.ForeColor = System.Drawing.Color.White; b.FlatStyle = System.Windows.Forms.FlatStyle.Flat; b.FlatAppearance.BorderSize = 0; b.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold); b.Cursor = System.Windows.Forms.Cursors.Hand; return b; }
        private System.Windows.Forms.Label MakeLabel(string name, string title, int x, int y, int size, bool bold) { var l = new System.Windows.Forms.Label(); l.Name = name; l.Text = title; l.Location = new System.Drawing.Point(x, y); l.AutoSize = true; l.Font = new System.Drawing.Font("Segoe UI", size, bold ? System.Drawing.FontStyle.Bold : System.Drawing.FontStyle.Regular); l.ForeColor = System.Drawing.Color.FromArgb(35, 35, 45); return l; }
        private System.Windows.Forms.Panel panelSidebar, panelTop, panelContent, panelHome, panelCategories, panelFavorites, panelCart, panelProfile;
        private System.Windows.Forms.FlowLayoutPanel flowProducts, flowFavorites;
        private System.Windows.Forms.DataGridView listCart, listOrders;
        private System.Windows.Forms.ComboBox cmbCategories;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch, btnHome, btnCategories, btnFavorites, btnCart, btnProfile, btnCheckout, btnRemoveCart, btnPlus, btnMinus, btnLogout, btnShowCategory;
        private System.Windows.Forms.Label lblLogo, lblCartTotal, lblProfileName, lblProfileEmail, lblProfileRole;
    }
}
