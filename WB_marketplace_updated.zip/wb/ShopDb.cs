﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace wb
{
    internal static class ShopDb
    {
        private static string Connection { get { return ConfigurationManager.ConnectionStrings["wb.Properties.Settings.WBConnectionString"].ConnectionString; } }
        public static DataTable Get(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(Connection))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddRange(parameters);
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    DataTable result = new DataTable(); adapter.Fill(result); return result;
                }
            }
        }
        public static int Run(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(Connection))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddRange(parameters); connection.Open(); return command.ExecuteNonQuery();
            }
        }
        public static object Value(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(Connection))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddRange(parameters); connection.Open(); return command.ExecuteScalar();
            }
        }
        public static SqlParameter P(string name, object value) { return new SqlParameter(name, value ?? DBNull.Value); }
    }
}
