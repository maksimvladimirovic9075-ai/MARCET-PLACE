using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace wb
{
 public partial class UserForm : Form
 {
  private int userId;
  private string cs = Properties.Settings.Default.WBConnectionString;
  public UserForm(int id) { InitializeComponent(); userId = id; }
  private void UserForm_Load(object sender, EventArgs e) { LoadCategories(); LoadProducts(); ShowPage(panelHome); }
  private void ShowPage(Panel page) { panelHome.Visible=false; panelCategories.Visible=false; panelFavorites.Visible=false; panelCart.Visible=false; panelProfile.Visible=false; page.Visible=true; page.BringToFront(); }
  private void LoadProducts(string search="", int category=0)
  {
   flowProducts.Controls.Clear();
   var products = new WBDataSetTableAdapters.ProductsTableAdapter().GetData();
   foreach(var p in products) if(p.IsActive && p.Name.IndexOf(search,StringComparison.OrdinalIgnoreCase)>=0 && (category==0 || p.CategoryID==category)) AddCard(flowProducts,p);
  }
  private void AddCard(FlowLayoutPanel flow, WBDataSet.ProductsRow p)
  {
   ProductCard card=new ProductCard(); card.SetProduct(p.ProductID,p.Name,p.IsDescriptionNull()?"":p.Description,p.Price,p.StockQuantity,p.IsImagePathNull()?"":p.ImagePath);
   card.BuyClicked += (s,e)=> { try { Exec("IF EXISTS(SELECT 1 FROM Cart WHERE UserID=@u AND ProductID=@p) UPDATE Cart SET Quantity=Quantity+1 WHERE UserID=@u AND ProductID=@p ELSE INSERT INTO Cart(UserID,ProductID,Quantity) VALUES(@u,@p,1)",p.ProductID); MessageBox.Show("Добавлено в корзину"); } catch(Exception ex) { Error(ex); } };
   card.FavoriteClicked += (s,e)=> { try { Exec("IF EXISTS(SELECT 1 FROM Favorites WHERE UserID=@u AND ProductID=@p) DELETE FROM Favorites WHERE UserID=@u AND ProductID=@p ELSE INSERT INTO Favorites(UserID,ProductID) VALUES(@u,@p)",p.ProductID); MessageBox.Show("Избранное обновлено"); if(panelFavorites.Visible) LoadFavorites(); } catch(Exception ex) { Error(ex); } };
   flow.Controls.Add(card);
  }
  private void LoadCategories() { cmbCategories.DisplayMember="CategoryName"; cmbCategories.ValueMember="CategoryID"; cmbCategories.DataSource=new WBDataSetTableAdapters.CategoriesTableAdapter().GetData(); }
  private void btnShowCategory_Click(object sender,EventArgs e) { if(cmbCategories.SelectedValue==null)return; LoadProducts("",Convert.ToInt32(cmbCategories.SelectedValue)); ShowPage(panelHome); }
  private void btnHome_Click(object sender,EventArgs e) { txtSearch.Clear(); LoadProducts(); ShowPage(panelHome); }
  private void btnCategories_Click(object sender,EventArgs e) { ShowPage(panelCategories); }
  private void btnFavorites_Click(object sender,EventArgs e) { LoadFavorites(); ShowPage(panelFavorites); }
  private void btnCart_Click(object sender,EventArgs e) { LoadCart(); ShowPage(panelCart); }
  private void btnProfile_Click(object sender,EventArgs e) { LoadProfile(); ShowPage(panelProfile); }
  private void btnSearch_Click(object sender,EventArgs e) { LoadProducts(txtSearch.Text.Trim()); ShowPage(panelHome); }
  private void txtSearch_KeyDown(object sender,KeyEventArgs e) { if(e.KeyCode==Keys.Enter) { btnSearch.PerformClick(); e.SuppressKeyPress=true; } }
  private void Error(Exception ex) { MessageBox.Show("Ошибка: "+ex.Message+"\nЕсли отсутствуют Cart/Favorites, выполните скрипт SETUP_WB.sql."); }
  private void Exec(string sql,int product=0) { using(var c=new SqlConnection(cs)) using(var q=new SqlCommand(sql,c)) { q.Parameters.AddWithValue("@u",userId); q.Parameters.AddWithValue("@p",product); c.Open(); q.ExecuteNonQuery(); } }
  private DataTable Read(string sql) { using(var c=new SqlConnection(cs)) using(var q=new SqlCommand(sql,c)) { q.Parameters.AddWithValue("@u",userId); var t=new DataTable(); new SqlDataAdapter(q).Fill(t); return t; } }
  private void LoadFavorites() { try { flowFavorites.Controls.Clear(); var ids=Read("SELECT ProductID FROM Favorites WHERE UserID=@u"); var products=new WBDataSetTableAdapters.ProductsTableAdapter().GetData(); foreach(DataRow id in ids.Rows) foreach(var p in products) if(p.ProductID==Convert.ToInt32(id["ProductID"]) && p.IsActive) AddCard(flowFavorites,p); } catch(Exception ex) { Error(ex); } }
  private void LoadCart() { try { listCart.DataSource=Read("SELECT c.CartID, p.Name AS [Товар], c.Quantity AS [Количество], p.Price AS [Цена], c.Quantity*p.Price AS [Сумма] FROM Cart c JOIN Products p ON p.ProductID=c.ProductID WHERE c.UserID=@u"); listCart.Columns["CartID"].Visible=false; decimal total=0; foreach(DataGridViewRow r in listCart.Rows) if(!r.IsNewRow) total+=Convert.ToDecimal(r.Cells["Сумма"].Value); lblCartTotal.Text="Итого: "+total.ToString("N0")+" ₽"; } catch(Exception ex) { Error(ex); } }
  private int SelectedCart() { if(listCart.CurrentRow==null)return 0; return Convert.ToInt32(listCart.CurrentRow.Cells["CartID"].Value); }
  private void ChangeCart(string sql) { int id=SelectedCart(); if(id==0)return; try { using(var c=new SqlConnection(cs)) using(var q=new SqlCommand(sql,c)) { q.Parameters.AddWithValue("@id",id); q.Parameters.AddWithValue("@u",userId); c.Open(); q.ExecuteNonQuery(); } LoadCart(); } catch(Exception ex) { Error(ex); } }
  private void btnRemoveCart_Click(object sender,EventArgs e) { ChangeCart("DELETE FROM Cart WHERE CartID=@id AND UserID=@u"); }
  private void btnPlus_Click(object sender,EventArgs e) { ChangeCart("UPDATE Cart SET Quantity=Quantity+1 WHERE CartID=@id AND UserID=@u"); }
  private void btnMinus_Click(object sender,EventArgs e) { ChangeCart("UPDATE Cart SET Quantity=Quantity-1 WHERE CartID=@id AND UserID=@u AND Quantity>1"); }
  private void btnCheckout_Click(object sender,EventArgs e)
  {
   try { using(var c=new SqlConnection(cs)) { c.Open(); using(var tr=c.BeginTransaction()) { try {
    var q=new SqlCommand("SELECT COUNT(*) FROM Cart WHERE UserID=@u",c,tr); q.Parameters.AddWithValue("@u",userId); if(Convert.ToInt32(q.ExecuteScalar())==0) { MessageBox.Show("Корзина пуста"); return; }
    q.CommandText="IF EXISTS(SELECT 1 FROM Cart c JOIN Products p ON p.ProductID=c.ProductID WHERE c.UserID=@u AND (p.StockQuantity<c.Quantity OR p.IsActive=0)) SELECT 1 ELSE SELECT 0";
    if(Convert.ToInt32(q.ExecuteScalar())!=0) { MessageBox.Show("Некоторых товаров недостаточно на складе"); return; }
    q.CommandText="INSERT INTO Orders(UserID,OrderDate,Status) VALUES(@u,GETDATE(),N'Новый'); SELECT CAST(SCOPE_IDENTITY() AS int)"; int order=Convert.ToInt32(q.ExecuteScalar()); q.Parameters.AddWithValue("@o",order);
    q.CommandText="INSERT INTO OrdersItems(OrderID,ProductID,Quantity,Price) SELECT @o,c.ProductID,c.Quantity,p.Price FROM Cart c JOIN Products p ON p.ProductID=c.ProductID WHERE c.UserID=@u"; q.ExecuteNonQuery();
    q.CommandText="UPDATE p SET p.StockQuantity=p.StockQuantity-c.Quantity FROM Products p JOIN Cart c ON c.ProductID=p.ProductID WHERE c.UserID=@u"; q.ExecuteNonQuery();
    q.CommandText="DELETE FROM Cart WHERE UserID=@u"; q.ExecuteNonQuery(); tr.Commit(); MessageBox.Show("Заказ №"+order+" оформлен!"); LoadCart();
   } catch { tr.Rollback(); throw; } } } } catch(Exception ex) { Error(ex); }
  }
  private void LoadProfile() { try { var users=new WBDataSetTableAdapters.UsersTableAdapter().GetData(); foreach(var u in users) if(u.UserID==userId) { lblProfileName.Text="Имя: "+u.Name; lblProfileEmail.Text="Почта: "+u.Email; lblProfileRole.Text="Роль: "+u.Role; break; } listOrders.DataSource=Read("SELECT OrderID AS [Заказ],OrderDate AS [Дата],Status AS [Статус] FROM Orders WHERE UserID=@u ORDER BY OrderDate DESC"); } catch(Exception ex) { Error(ex); } }
  private void btnLogout_Click(object sender,EventArgs e) { Close(); }
 }
}
