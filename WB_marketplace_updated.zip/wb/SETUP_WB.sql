﻿-- Выполнить ОДИН РАЗ в существующей базе WB (не удаляет существующие данные).
USE WB;
IF OBJECT_ID(N'dbo.Favorites',N'U') IS NULL
CREATE TABLE dbo.Favorites (FavoriteID INT IDENTITY(1,1) PRIMARY KEY, UserID INT NOT NULL REFERENCES dbo.Users(UserID), ProductID INT NOT NULL REFERENCES dbo.Products(ProductID), CONSTRAINT UQ_Favorites_User_Product UNIQUE(UserID,ProductID));
IF OBJECT_ID(N'dbo.Cart',N'U') IS NULL
CREATE TABLE dbo.Cart (CartID INT IDENTITY(1,1) PRIMARY KEY, UserID INT NOT NULL REFERENCES dbo.Users(UserID), ProductID INT NOT NULL REFERENCES dbo.Products(ProductID), Quantity INT NOT NULL DEFAULT 1, CONSTRAINT UQ_Cart_User_Product UNIQUE(UserID,ProductID), CONSTRAINT CK_Cart_Quantity CHECK(Quantity>0));
