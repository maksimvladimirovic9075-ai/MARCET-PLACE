﻿using System;
using System.Data;
using System.IO;
using System.Windows.Forms;
namespace wb
{
    public partial class AdminForm : Form
    {
        public AdminForm() { InitializeComponent(); }
        private void AdminForm_Load(object sender, EventArgs e) { RefreshAll(); }
        private void RefreshAll()
        {
            gridProducts.DataSource = ShopDb.Get("SELECT ProductID,CategoryID,Name,Description,Price,StockQuantity,IsActive,ImagePath FROM dbo.Products ORDER BY ProductID DESC");
            gridCategories.DataSource = ShopDb.Get("SELECT CategoryID,CategoryName,Description FROM dbo.Categories ORDER BY CategoryID");
            gridOrders.DataSource = ShopDb.Get("SELECT o.OrderID,o.UserID,u.Email,o.OrderDate,o.Status FROM dbo.Orders o JOIN dbo.Users u ON u.UserID=o.UserID ORDER BY o.OrderDate DESC");
            cmbCategory.DataSource = ShopDb.Get("SELECT CategoryID,CategoryName FROM dbo.Categories ORDER BY CategoryName");
            cmbCategory.DisplayMember = "CategoryName"; cmbCategory.ValueMember = "CategoryID";
        }
        private int Selected(DataGridView grid, string column) { return grid.CurrentRow == null ? 0 : Convert.ToInt32(grid.CurrentRow.Cells[column].Value); }
        private void gridProducts_SelectionChanged(object sender, EventArgs e)
        {
            if (gridProducts.CurrentRow == null) return;
            DataGridViewRow r = gridProducts.CurrentRow;
            txtName.Text = Convert.ToString(r.Cells["Name"].Value); txtDescription.Text = Convert.ToString(r.Cells["Description"].Value);
            txtPrice.Text = Convert.ToString(r.Cells["Price"].Value); txtStock.Text = Convert.ToString(r.Cells["StockQuantity"].Value);
            txtImage.Text = Convert.ToString(r.Cells["ImagePath"].Value);
            if (cmbCategory.DataSource != null) cmbCategory.SelectedValue = r.Cells["CategoryID"].Value;
            string path = Path.Combine(Application.StartupPath, "Images", txtImage.Text);
            picPreview.ImageLocation = File.Exists(path) ? path : null;
        }
        private bool Valid() { decimal price; int stock; if (txtName.Text.Trim() == "" || !decimal.TryParse(txtPrice.Text, out price) || price < 0 || !int.TryParse(txtStock.Text, out stock) || stock < 0 || cmbCategory.SelectedValue == null) { MessageBox.Show("Проверьте название, цену, остаток и категорию"); return false; } return true; }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!Valid()) return;
            try { ShopDb.Run("INSERT INTO dbo.Products(CategoryID,Name,Description,Price,StockQuantity,IsActive,ImagePath) VALUES(@c,@n,@d,@p,@s,1,@i)", ShopDb.P("@c", cmbCategory.SelectedValue), ShopDb.P("@n", txtName.Text.Trim()), ShopDb.P("@d", txtDescription.Text), ShopDb.P("@p", decimal.Parse(txtPrice.Text)), ShopDb.P("@s", int.Parse(txtStock.Text)), ShopDb.P("@i", txtImage.Text)); RefreshAll(); } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            int id = Selected(gridProducts, "ProductID"); if (id == 0 || !Valid()) return;
            try { ShopDb.Run("UPDATE dbo.Products SET CategoryID=@c,Name=@n,Description=@d,Price=@p,StockQuantity=@s,ImagePath=@i WHERE ProductID=@id", ShopDb.P("@c", cmbCategory.SelectedValue), ShopDb.P("@n", txtName.Text.Trim()), ShopDb.P("@d", txtDescription.Text), ShopDb.P("@p", decimal.Parse(txtPrice.Text)), ShopDb.P("@s", int.Parse(txtStock.Text)), ShopDb.P("@i", txtImage.Text), ShopDb.P("@id", id)); RefreshAll(); } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = Selected(gridProducts, "ProductID"); if (id == 0 || MessageBox.Show("Скрыть товар из каталога?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try { ShopDb.Run("UPDATE dbo.Products SET IsActive=0 WHERE ProductID=@id", ShopDb.P("@id", id)); RefreshAll(); } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void btnImage_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Filter = "Изображения|*.jpg;*.jpeg;*.png";
                if (dialog.ShowDialog() != DialogResult.OK) return;
                string folder = Path.Combine(Application.StartupPath, "Images"); Directory.CreateDirectory(folder);
                string filename = Guid.NewGuid().ToString("N") + Path.GetExtension(dialog.FileName);
                File.Copy(dialog.FileName, Path.Combine(folder, filename)); txtImage.Text = filename;
                picPreview.ImageLocation = Path.Combine(folder, filename);
            }
        }
        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            if (txtCategory.Text.Trim() == "") return;
            try { ShopDb.Run("INSERT INTO dbo.Categories(CategoryName,Description) VALUES(@n,@d)", ShopDb.P("@n", txtCategory.Text.Trim()), ShopDb.P("@d", txtCategoryDescription.Text)); RefreshAll(); } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void btnDeleteCategory_Click(object sender, EventArgs e)
        {
            int id = Selected(gridCategories, "CategoryID"); if (id == 0) return;
            try { ShopDb.Run("DELETE FROM dbo.Categories WHERE CategoryID=@id", ShopDb.P("@id", id)); RefreshAll(); } catch (Exception ex) { MessageBox.Show("Нельзя удалить категорию с товарами. " + ex.Message); }
        }
        private void btnStatus_Click(object sender, EventArgs e)
        {
            int id = Selected(gridOrders, "OrderID"); if (id == 0 || cmbStatus.SelectedItem == null) return;
            try { ShopDb.Run("UPDATE dbo.Orders SET Status=@s WHERE OrderID=@id", ShopDb.P("@s", cmbStatus.SelectedItem.ToString()), ShopDb.P("@id", id)); RefreshAll(); } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
