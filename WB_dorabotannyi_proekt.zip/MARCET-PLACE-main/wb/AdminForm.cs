using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;
namespace wb
{
 public partial class AdminForm : Form
 {
  private string cs=Properties.Settings.Default.WBConnectionString;
  public AdminForm() { InitializeComponent(); }
  private void AdminForm_Load(object sender,EventArgs e) { RefreshAll(); }
  private DataTable Read(string sql) { var t=new DataTable(); using(var c=new SqlConnection(cs)) { new SqlDataAdapter(sql,c).Fill(t); } return t; }
  private void RefreshAll() { try { gridProducts.DataSource=Read("SELECT ProductID,CategoryID,Name,Description,Price,StockQuantity,IsActive,ImagePath FROM Products"); gridCategories.DataSource=Read("SELECT CategoryID,CategoryName,Description FROM Categories"); gridOrders.DataSource=Read("SELECT OrderID,UserID,OrderDate,Status FROM Orders ORDER BY OrderDate DESC"); cmbCategory.DisplayMember="CategoryName"; cmbCategory.ValueMember="CategoryID"; cmbCategory.DataSource=Read("SELECT CategoryID,CategoryName FROM Categories"); } catch(Exception ex) { MessageBox.Show(ex.Message); } }
  private int Selected(DataGridView g,string id) { return g.CurrentRow==null?0:Convert.ToInt32(g.CurrentRow.Cells[id].Value); }
  private void gridProducts_SelectionChanged(object sender,EventArgs e) { if(gridProducts.CurrentRow==null)return; var r=gridProducts.CurrentRow; txtName.Text=Convert.ToString(r.Cells["Name"].Value); txtDescription.Text=Convert.ToString(r.Cells["Description"].Value); txtPrice.Text=Convert.ToString(r.Cells["Price"].Value); txtStock.Text=Convert.ToString(r.Cells["StockQuantity"].Value); txtImage.Text=Convert.ToString(r.Cells["ImagePath"].Value); cmbCategory.SelectedValue=r.Cells["CategoryID"].Value; }
  private void btnImage_Click(object sender,EventArgs e) { using(var d=new OpenFileDialog()) { d.Filter="Изображения|*.jpg;*.jpeg;*.png"; if(d.ShowDialog()!=DialogResult.OK)return; string folder=Path.Combine(Application.StartupPath,"Images"); Directory.CreateDirectory(folder); File.Copy(d.FileName,Path.Combine(folder,Path.GetFileName(d.FileName)),true); txtImage.Text=Path.GetFileName(d.FileName); MessageBox.Show("Фото скопировано в Images"); } }
  private void ProductSave(bool edit) { decimal price; int stock; if(txtName.Text.Trim()=="" || !decimal.TryParse(txtPrice.Text,out price) || price<0 || !int.TryParse(txtStock.Text,out stock) || stock<0 || cmbCategory.SelectedValue==null) { MessageBox.Show("Проверьте название, цену и остаток"); return; } int id=edit?Selected(gridProducts,"ProductID"):0; if(edit && id==0)return; string sql=edit?"UPDATE Products SET Name=@n,Description=@d,Price=@price,StockQuantity=@stock,CategoryID=@cat,ImagePath=@img WHERE ProductID=@id":"INSERT INTO Products(Name,Description,Price,StockQuantity,CategoryID,IsActive,ImagePath) VALUES(@n,@d,@price,@stock,@cat,1,@img)"; try { using(var c=new SqlConnection(cs)) using(var q=new SqlCommand(sql,c)) { q.Parameters.AddWithValue("@id",id); q.Parameters.AddWithValue("@n",txtName.Text.Trim()); q.Parameters.AddWithValue("@d",txtDescription.Text); q.Parameters.AddWithValue("@price",price); q.Parameters.AddWithValue("@stock",stock); q.Parameters.AddWithValue("@cat",Convert.ToInt32(cmbCategory.SelectedValue)); q.Parameters.AddWithValue("@img",txtImage.Text.Trim()); c.Open(); q.ExecuteNonQuery(); } RefreshAll(); } catch(Exception ex) { MessageBox.Show(ex.Message); } }
  private void btnAdd_Click(object sender,EventArgs e) { ProductSave(false); }
  private void btnSave_Click(object sender,EventArgs e) { ProductSave(true); }
  private void btnDelete_Click(object sender,EventArgs e) { int id=Selected(gridProducts,"ProductID"); if(id==0 || MessageBox.Show("Скрыть товар из каталога?","Подтверждение",MessageBoxButtons.YesNo)!=DialogResult.Yes)return; Run("UPDATE Products SET IsActive=0 WHERE ProductID=@id",id); }
  private void Run(string sql,int id,string value="") { try { using(var c=new SqlConnection(cs)) using(var q=new SqlCommand(sql,c)) { q.Parameters.AddWithValue("@id",id); q.Parameters.AddWithValue("@v",value); c.Open(); q.ExecuteNonQuery(); } RefreshAll(); } catch(Exception ex) { MessageBox.Show(ex.Message); } }
  private void btnRefresh_Click(object sender,EventArgs e) { RefreshAll(); }
  private void btnAddCategory_Click(object sender,EventArgs e) { if(txtCategory.Text.Trim()=="")return; Run("INSERT INTO Categories(CategoryName,Description) VALUES(@v,N'')",0,txtCategory.Text.Trim()); txtCategory.Clear(); }
  private void btnDeleteCategory_Click(object sender,EventArgs e) { int id=Selected(gridCategories,"CategoryID"); if(id==0)return; Run("DELETE FROM Categories WHERE CategoryID=@id",id); }
  private void btnStatus_Click(object sender,EventArgs e) { int id=Selected(gridOrders,"OrderID"); if(id==0 || cmbStatus.SelectedItem==null)return; Run("UPDATE Orders SET Status=@v WHERE OrderID=@id",id,cmbStatus.SelectedItem.ToString()); }
 }
}
