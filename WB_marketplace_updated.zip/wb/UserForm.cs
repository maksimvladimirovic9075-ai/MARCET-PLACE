﻿using System;
using System.Data;
using System.Windows.Forms;
namespace wb
{
    public partial class UserForm : Form
    {
        private int userId;
        public UserForm() : this(0) { }
        public UserForm(int id) { InitializeComponent(); userId = id; }
        private void UserForm_Load(object sender, EventArgs e) { LoadProducts(); ShowPage(panelHome); }
        private void ShowPage(Panel page)
        {
            panelHome.Visible = false; panelCategories.Visible = false;
            panelFavorites.Visible = false; panelCart.Visible = false; panelProfile.Visible = false;
            page.Visible = true; page.BringToFront();
        }
        private void LoadProducts(string search = "", int category = 0)
        {
            flowProducts.Controls.Clear();
            var products = new WBDataSetTableAdapters.ProductsTableAdapter().GetData();
            foreach (var p in products)
                if (p.IsActive && (category == 0 || p.CategoryID == category) && p.Name.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0)
                    AddCard(flowProducts, p.ProductID, p.Name, p.IsDescriptionNull() ? "" : p.Description, p.Price, p.StockQuantity, p.IsImagePathNull() ? "" : p.ImagePath);
        }
        private void AddCard(FlowLayoutPanel target, int id, string name, string description, decimal price, int stock, string image)
        {
            ProductCard card = new ProductCard();
            card.SetProduct(id, name, description, price, stock, image);
            card.BuyClicked += (s, e) => { try { ShopDb.Run("IF EXISTS(SELECT 1 FROM dbo.Cart WHERE UserID=@u AND ProductID=@p) UPDATE dbo.Cart SET Quantity=Quantity+1 WHERE UserID=@u AND ProductID=@p ELSE INSERT INTO dbo.Cart(UserID,ProductID,Quantity) VALUES(@u,@p,1)", ShopDb.P("@u", userId), ShopDb.P("@p", id)); MessageBox.Show("Товар добавлен в корзину"); } catch (Exception ex) { MessageBox.Show(ex.Message); } };
            card.FavoriteClicked += (s, e) => { try { int n = ShopDb.Run("DELETE FROM dbo.Favorites WHERE UserID=@u AND ProductID=@p", ShopDb.P("@u", userId), ShopDb.P("@p", id)); if (n == 0) { ShopDb.Run("INSERT INTO dbo.Favorites(UserID,ProductID) VALUES(@u,@p)", ShopDb.P("@u", userId), ShopDb.P("@p", id)); MessageBox.Show("Добавлено в избранное"); } else MessageBox.Show("Удалено из избранного"); if (target == flowFavorites) LoadFavorites(); } catch (Exception ex) { MessageBox.Show(ex.Message); } };
            target.Controls.Add(card);
        }
        private void btnHome_Click(object sender, EventArgs e) { txtSearch.Clear(); LoadProducts(); ShowPage(panelHome); }
        private void btnSearch_Click(object sender, EventArgs e) { Search(); }
        private void btnSearch_Click_1(object sender, EventArgs e) { Search(); }
        private void Search() { LoadProducts(txtSearch.Text.Trim()); ShowPage(panelHome); }
        private void btnSearch_KeyDown(object sender, KeyEventArgs e) { if (e.KeyCode == Keys.Enter) { Search(); e.SuppressKeyPress = true; } }
        private void btnFilters_Click(object sender, EventArgs e) { btnCategories_Click(sender, e); }
        private void btnCategories_Click(object sender, EventArgs e)
        {
            flowCategories.Controls.Clear();
            var categories = new WBDataSetTableAdapters.CategoriesTableAdapter().GetData();
            foreach (var category in categories)
            {
                int id = category.CategoryID;
                Button button = new Button(); // One data-driven tile per database category.
                button.Text = category.CategoryName; button.Width = 260; button.Height = 140;
                button.Margin = new Padding(10); button.BackColor = System.Drawing.Color.White;
                button.ForeColor = System.Drawing.Color.DarkViolet;
                button.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
                button.FlatStyle = FlatStyle.Flat; button.FlatAppearance.BorderSize = 0;
                button.Click += (s, args) => { txtSearch.Clear(); LoadProducts("", id); ShowPage(panelHome); };
                flowCategories.Controls.Add(button);
            }
            ShowPage(panelCategories);
        }
        private void btnFavorites_Click(object sender, EventArgs e) { LoadFavorites(); ShowPage(panelFavorites); }
        private void LoadFavorites()
        {
            flowFavorites.Controls.Clear();
            DataTable rows = ShopDb.Get("SELECT p.* FROM dbo.Products p INNER JOIN dbo.Favorites f ON f.ProductID=p.ProductID WHERE f.UserID=@u", ShopDb.P("@u", userId));
            foreach (DataRow p in rows.Rows) AddCard(flowFavorites, (int)p["ProductID"], p["Name"].ToString(), p["Description"].ToString(), (decimal)p["Price"], (int)p["StockQuantity"], p["ImagePath"].ToString());
        }
        private void btnCart_Click(object sender, EventArgs e) { LoadCart(); ShowPage(panelCart); }
        private void LoadCart()
        {
            flowCart.Controls.Clear(); decimal total = 0;
            DataTable rows = ShopDb.Get("SELECT c.ProductID,p.Name,p.Price,c.Quantity FROM dbo.Cart c JOIN dbo.Products p ON p.ProductID=c.ProductID WHERE c.UserID=@u", ShopDb.P("@u", userId));
            foreach (DataRow row in rows.Rows)
            {
                int id = (int)row["ProductID"]; int quantity = (int)row["Quantity"]; decimal price = (decimal)row["Price"];
                total += price * quantity;
                Panel line = new Panel(); line.Width = 620; line.Height = 78; line.BackColor = System.Drawing.Color.White; line.Margin = new Padding(5);
                Label name = new Label(); name.Text = row["Name"] + "   " + price.ToString("N0") + " ₽   × " + quantity; name.Location = new System.Drawing.Point(12, 12); name.AutoSize = true; line.Controls.Add(name);
                Button minus = new Button(); minus.Text = "−"; minus.Location = new System.Drawing.Point(380, 38); minus.Size = new System.Drawing.Size(48, 30);
                minus.Click += (s, e) => { ShopDb.Run("DELETE FROM dbo.Cart WHERE UserID=@u AND ProductID=@p AND Quantity=1; UPDATE dbo.Cart SET Quantity=Quantity-1 WHERE UserID=@u AND ProductID=@p AND Quantity>1", ShopDb.P("@u", userId), ShopDb.P("@p", id)); LoadCart(); }; line.Controls.Add(minus);
                Button plus = new Button(); plus.Text = "+"; plus.Location = new System.Drawing.Point(434, 38); plus.Size = new System.Drawing.Size(48, 30);
                plus.Click += (s, e) => { ShopDb.Run("UPDATE dbo.Cart SET Quantity=Quantity+1 WHERE UserID=@u AND ProductID=@p AND Quantity < (SELECT StockQuantity FROM dbo.Products WHERE ProductID=@p)", ShopDb.P("@u", userId), ShopDb.P("@p", id)); LoadCart(); }; line.Controls.Add(plus);
                Button remove = new Button(); remove.Text = "Удалить"; remove.Location = new System.Drawing.Point(488, 38); remove.Size = new System.Drawing.Size(100, 30);
                remove.Click += (s, e) => { ShopDb.Run("DELETE FROM dbo.Cart WHERE UserID=@u AND ProductID=@p", ShopDb.P("@u", userId), ShopDb.P("@p", id)); LoadCart(); }; line.Controls.Add(remove);
                flowCart.Controls.Add(line);
            }
            lblTotal.Text = "Итого: " + total.ToString("N0") + " ₽";
        }
        private void btnCheckout_Click(object sender, EventArgs e)
        {
            try
            {
                int count = Convert.ToInt32(ShopDb.Value("SELECT COUNT(*) FROM dbo.Cart WHERE UserID=@u", ShopDb.P("@u", userId)));
                if (count == 0) { MessageBox.Show("Корзина пуста"); return; }
                int order = Convert.ToInt32(ShopDb.Value(@"SET XACT_ABORT ON; BEGIN TRANSACTION;
IF EXISTS(SELECT 1 FROM dbo.Cart c JOIN dbo.Products p ON p.ProductID=c.ProductID WHERE c.UserID=@u AND (p.StockQuantity<c.Quantity OR p.IsActive=0)) BEGIN ROLLBACK TRANSACTION; SELECT -1; END
ELSE BEGIN INSERT INTO dbo.Orders(UserID,OrderDate,Status) VALUES(@u,GETDATE(),N'Новый'); DECLARE @id int=SCOPE_IDENTITY();
INSERT INTO dbo.OrdersItems(OrderID,ProductID,Quantity,Price) SELECT @id,c.ProductID,c.Quantity,p.Price FROM dbo.Cart c JOIN dbo.Products p ON p.ProductID=c.ProductID WHERE c.UserID=@u;
UPDATE p SET p.StockQuantity=p.StockQuantity-c.Quantity FROM dbo.Products p JOIN dbo.Cart c ON c.ProductID=p.ProductID WHERE c.UserID=@u;
DELETE FROM dbo.Cart WHERE UserID=@u; COMMIT TRANSACTION; SELECT @id; END", ShopDb.P("@u", userId)));
                if (order == -1) MessageBox.Show("Некоторых товаров недостаточно на складе");
                else { MessageBox.Show("Заказ №" + order + " оформлен!"); LoadCart(); }
            }
            catch (Exception ex) { MessageBox.Show("Ошибка оформления: " + ex.Message); }
        }
        private void btnProfile_Click(object sender, EventArgs e)
        {
            DataTable users = ShopDb.Get("SELECT Name,Email,Role FROM dbo.Users WHERE UserID=@u", ShopDb.P("@u", userId));
            if (users.Rows.Count > 0) lblProfileInfo.Text = "Имя: " + users.Rows[0]["Name"] + "\nПочта: " + users.Rows[0]["Email"] + "\nРоль: " + users.Rows[0]["Role"];
            dgvHistory.DataSource = ShopDb.Get("SELECT OrderID AS [Номер заказа],OrderDate AS [Дата],Status AS [Статус] FROM dbo.Orders WHERE UserID=@u ORDER BY OrderDate DESC", ShopDb.P("@u", userId));
            ShowPage(panelProfile);
        }
        private void productCard5_Load(object sender, EventArgs e) { }
        private void flowProducts_Paint(object sender, PaintEventArgs e) { }
    }
}
