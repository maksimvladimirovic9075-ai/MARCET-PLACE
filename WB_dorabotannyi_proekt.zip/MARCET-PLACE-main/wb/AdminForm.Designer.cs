namespace wb
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.lblTitle = new System.Windows.Forms.Label(); this.lblTitle.Name="lblTitle"; this.lblTitle.Text="WB  /  Панель администратора"; this.lblTitle.Font=new System.Drawing.Font("Segoe UI",20F,System.Drawing.FontStyle.Bold); this.lblTitle.ForeColor=System.Drawing.Color.FromArgb(111,45,220); this.lblTitle.Location=new System.Drawing.Point(25,18); this.lblTitle.AutoSize=true;
            this.tabs=new System.Windows.Forms.TabControl(); this.tabs.Name="tabs"; this.tabs.Location=new System.Drawing.Point(25,75); this.tabs.Size=new System.Drawing.Size(1120,680); this.tabs.Anchor=System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Bottom|System.Windows.Forms.AnchorStyles.Left|System.Windows.Forms.AnchorStyles.Right;
            this.tabProducts=new System.Windows.Forms.TabPage("Товары"); this.tabCategories=new System.Windows.Forms.TabPage("Категории"); this.tabOrders=new System.Windows.Forms.TabPage("Заказы"); this.tabs.TabPages.AddRange(new System.Windows.Forms.TabPage[]{tabProducts,tabCategories,tabOrders});
            this.gridProducts=Grid("gridProducts",20,15,1060,330); this.gridCategories=Grid("gridCategories",20,15,1060,430); this.gridOrders=Grid("gridOrders",20,15,1060,580);
            this.txtName=Box("txtName",20,385,280); this.txtDescription=Box("txtDescription",315,385,380); this.txtPrice=Box("txtPrice",710,385,130); this.txtStock=Box("txtStock",855,385,130); this.cmbCategory=new System.Windows.Forms.ComboBox(); this.cmbCategory.Name="cmbCategory"; this.cmbCategory.DropDownStyle=System.Windows.Forms.ComboBoxStyle.DropDownList; this.cmbCategory.Location=new System.Drawing.Point(20,455); this.cmbCategory.Width=260;
            this.txtImage=Box("txtImage",300,455,390); this.btnImage=Button("btnImage","Выбрать фото",710,453,160); this.btnAdd=Button("btnAdd","Добавить",20,520,150); this.btnSave=Button("btnSave","Сохранить изменения",185,520,210); this.btnDelete=Button("btnDelete","Удалить",410,520,150); this.btnRefresh=Button("btnRefresh","Обновить",575,520,150);
            this.tabProducts.Controls.AddRange(new System.Windows.Forms.Control[]{gridProducts,Label("Название / Описание / Цена / Остаток",20,350),txtName,txtDescription,txtPrice,txtStock,Label("Категория / Имя файла изображения",20,425),cmbCategory,txtImage,btnImage,btnAdd,btnSave,btnDelete,btnRefresh});
            this.txtCategory=Box("txtCategory",20,475,360); this.btnAddCategory=Button("btnAddCategory","Добавить категорию",400,472,210); this.btnDeleteCategory=Button("btnDeleteCategory","Удалить категорию",625,472,210); this.tabCategories.Controls.AddRange(new System.Windows.Forms.Control[]{gridCategories,txtCategory,btnAddCategory,btnDeleteCategory});
            this.cmbStatus=new System.Windows.Forms.ComboBox(); this.cmbStatus.Name="cmbStatus"; this.cmbStatus.DropDownStyle=System.Windows.Forms.ComboBoxStyle.DropDownList; this.cmbStatus.Items.AddRange(new object[]{"Новый","В обработке","Отправлен","Доставлен","Отменён"}); this.cmbStatus.Location=new System.Drawing.Point(20,605); this.cmbStatus.Width=230; this.btnStatus=Button("btnStatus","Изменить статус",270,603,210); this.tabOrders.Controls.AddRange(new System.Windows.Forms.Control[]{gridOrders,cmbStatus,btnStatus});
            this.Controls.AddRange(new System.Windows.Forms.Control[]{lblTitle,tabs}); this.ClientSize=new System.Drawing.Size(1180,790); this.MinimumSize=new System.Drawing.Size(1120,760); this.StartPosition=System.Windows.Forms.FormStartPosition.CenterScreen; this.Text="WB — Администратор"; this.BackColor=System.Drawing.Color.FromArgb(248,249,253); this.Font=new System.Drawing.Font("Segoe UI",10F);
            this.Load+=new System.EventHandler(this.AdminForm_Load); this.gridProducts.SelectionChanged+=new System.EventHandler(this.gridProducts_SelectionChanged); this.btnImage.Click+=new System.EventHandler(this.btnImage_Click); this.btnAdd.Click+=new System.EventHandler(this.btnAdd_Click); this.btnSave.Click+=new System.EventHandler(this.btnSave_Click); this.btnDelete.Click+=new System.EventHandler(this.btnDelete_Click); this.btnRefresh.Click+=new System.EventHandler(this.btnRefresh_Click); this.btnAddCategory.Click+=new System.EventHandler(this.btnAddCategory_Click); this.btnDeleteCategory.Click+=new System.EventHandler(this.btnDeleteCategory_Click); this.btnStatus.Click+=new System.EventHandler(this.btnStatus_Click); this.ResumeLayout(false);
        }
        private System.Windows.Forms.DataGridView Grid(string name,int x,int y,int w,int h) { var g=new System.Windows.Forms.DataGridView(); g.Name=name; g.Location=new System.Drawing.Point(x,y); g.Size=new System.Drawing.Size(w,h); g.ReadOnly=true; g.AllowUserToAddRows=false; g.MultiSelect=false; g.SelectionMode=System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect; g.AutoSizeColumnsMode=System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill; g.BackgroundColor=System.Drawing.Color.White; g.Anchor=System.Windows.Forms.AnchorStyles.Top|System.Windows.Forms.AnchorStyles.Left|System.Windows.Forms.AnchorStyles.Right; return g; }
        private System.Windows.Forms.TextBox Box(string name,int x,int y,int w) { var t=new System.Windows.Forms.TextBox(); t.Name=name; t.Location=new System.Drawing.Point(x,y); t.Width=w; return t; }
        private System.Windows.Forms.Label Label(string title,int x,int y) { var l=new System.Windows.Forms.Label(); l.Text=title; l.Location=new System.Drawing.Point(x,y); l.AutoSize=true; return l; }
        private System.Windows.Forms.Button Button(string name,string title,int x,int y,int w) { var b=new System.Windows.Forms.Button(); b.Name=name; b.Text=title; b.Location=new System.Drawing.Point(x,y); b.Size=new System.Drawing.Size(w,38); b.FlatStyle=System.Windows.Forms.FlatStyle.Flat; b.FlatAppearance.BorderSize=0; b.BackColor=System.Drawing.Color.FromArgb(111,45,220); b.ForeColor=System.Drawing.Color.White; b.Cursor=System.Windows.Forms.Cursors.Hand; return b; }
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TabControl tabs;
        private System.Windows.Forms.TabPage tabProducts,tabCategories,tabOrders;
        private System.Windows.Forms.DataGridView gridProducts,gridCategories,gridOrders;
        private System.Windows.Forms.TextBox txtName,txtDescription,txtPrice,txtStock,txtImage,txtCategory;
        private System.Windows.Forms.ComboBox cmbCategory,cmbStatus;
        private System.Windows.Forms.Button btnImage,btnAdd,btnSave,btnDelete,btnRefresh,btnAddCategory,btnDeleteCategory,btnStatus;
    }
}
